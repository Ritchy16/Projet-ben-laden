/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simmissile;

/**
 *
 * @author User
 */
public class SimMissile  {


    
        // Création d'un missile avec des valeurs initiales
        Missile missile = new Missile(0, 0, 100, 45, 1000, 10);

        // Création d'une trajectoire vide
        Trajectoire trajectoire = new Trajectoire();

        // Création d'une simulation avec le missile et la trajectoire
        Simulation simulation = new Simulation(missile, trajectoire);

        // Démarrage de la simulation
    
}    

