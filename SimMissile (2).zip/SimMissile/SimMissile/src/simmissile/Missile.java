/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simmissile;

/**
 *
 * @author User
 */
public class Missile {
    private double positionX;
    private double positionY;
    private double vitesse;
    private double angle;
    private double energie;
    private double acceleration;

    // Constructeur
    public Missile(double positionX, double positionY, double vitesse, double angle, double energie, double acceleration) {
        this.positionX = positionX;
        this.positionY = positionY;
        this.vitesse = vitesse;
        this.angle = angle;
        this.energie = energie;
        this.acceleration = acceleration;
    }

    // Méthodes getters et setters pour positionX
    public double getPositionX() {
        return positionX;
    }

    public void setPositionX(double positionX) {
        this.positionX = positionX;
    }

    // Méthodes getters et setters pour positionY
    public double getPositionY() {
        return positionY;
    }

    public void setPositionY(double positionY) {
        this.positionY = positionY;
    }

    // Méthodes getters et setters pour vitesse
    public double getVitesse() {
        return vitesse;
    }

    public void setVitesse(double vitesse) {
        this.vitesse = vitesse;
    }

    // Méthodes getters et setters pour angle
    public double getAngle() {
        return angle;
    }

    public void setAngle(double angle) {
        this.angle = angle;
    }

    // Méthodes getters et setters pour energie
    public double getEnergie() {
        return energie;
    }

    public void setEnergie(double energie) {
        this.energie = energie;
    }

    // Méthodes getters et setters pour acceleration
    public double getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(double acceleration) {
        this.acceleration = acceleration;
    }
}

