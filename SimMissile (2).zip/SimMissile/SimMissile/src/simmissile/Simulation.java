/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simmissile;

/**
 *
 * @author User
 */
public class Simulation {
    private Missile missile;
    private Trajectoire trajectoire;
    private String conditionsMeteo; // Facultatif
    private String resultatSimulation; // Succès, Échec, Données de performance

    // Constructeur
    public Simulation(Missile missile, Trajectoire trajectoire) {
        this.missile = missile;
        this.trajectoire = trajectoire;
        this.conditionsMeteo = "";
        this.resultatSimulation = "";
    }

    // Méthodes pour gérer la simulation
    public void demarrerSimulation() {
        // Implémenter la logique de simulation
    }

    // Getters et Setters
    // À compléter selon le besoin

    String getResultatSimulation() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

