/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package simmissile;

/**
 *
 * @author User
 */
public class SimMissile {


    public static void main(String[] args) {
        // Création d'un missile avec des valeurs initiales
        Missile missile = new Missile(0, 0, 100, 45, 1000, 10);

        // Création d'une trajectoire vide
        Trajectoire trajectoire = new Trajectoire();

        // Création d'une simulation avec le missile et la trajectoire
        Simulation simulation = new Simulation(missile, trajectoire);

        // Démarrage de la simulation
        simulation.demarrerSimulation();

        // Afficher le résultat de la simulation
        // Cela nécessitera d'implémenter la logique de simulation et les méthodes d'affichage
        System.out.println("Résultat de la simulation: " + simulation.getResultatSimulation());
    }
}

