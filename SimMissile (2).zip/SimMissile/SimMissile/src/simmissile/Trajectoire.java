/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package simmissile;

/**
 *
 * @author User
 */
import java.util.List;
import java.util.ArrayList;

public class Trajectoire {
    private List<Double[]> listePositions; // Liste des coordonnées [X, Y]
    private double distanceTotale;
    private double tempsDeVol;

    // Constructeur
    public Trajectoire() {
        this.listePositions = new ArrayList<>();
        this.distanceTotale = 0;
        this.tempsDeVol = 0;
    }

    // Méthodes pour manipuler la trajectoire
    public void ajouterPosition(double x, double y) {
        this.listePositions.add(new Double[]{x, y});
        // Calculer distanceTotale et tempsDeVol si nécessaire
    }

    // Getters et Setters
    // À compléter selon le besoin
}

